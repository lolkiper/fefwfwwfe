'use strict';

/**
 * processor.js — вся работа с FFmpeg.
 *
 * Для каждого исходного видео собирается один ffmpeg-процесс, который:
 *   1) берёт первые X% исходника,
 *   2) подставляет за ними ролик Shorts,
 *   3) добавляет оставшийся хвост исходника,
 *   4) (опционально) накладывает оверлей на весь хронометраж,
 *   5) пишет результат в esN.mp4 (H.264/H.265) или esN.mov (ProRes).
 *
 * Модуль не зависит от Electron и может запускаться обычным Node (см. scripts/smoke-test.js).
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');
const ffmpeg = require('fluent-ffmpeg');

const VIDEO_EXTENSIONS = [
  '.mp4', '.mov', '.mkv', '.avi', '.m4v', '.webm', '.wmv',
  '.flv', '.mpg', '.mpeg', '.mts', '.m2ts', '.ts', '.3gp', '.ogv'
];

const AUDIO_SAMPLE_RATE = 48000;
const AUDIO_LAYOUT = 'stereo';

/** Быстрее bicubic, для Shorts разницы почти нет. */
const SCALE_FLAGS = 'fast_bilinear';
/** Запасной FPS, если у исходника нет корректной частоты. */
const MAX_OUTPUT_FPS = 60;
const MAX_KEEP_FPS = 120;
/**
 * Мягкий потолок чтения входа. На GPU нужен всегда: без него новый ffmpeg
 * в первые кадры забивает NVENC очередью, и Video Encode скачет до 100%
 * на стыке файлов. Скорость выше типичного NVENC (4–8×), поэтому сам
 * рендер почти не замедляется — режется только стартовый выброс.
 */
const ENCODE_PACE_SPEED = 3;
const GPU_PACE_BALANCED = 10;
const GPU_PACE_HIGH = 16;
/** Один файл = один ffmpeg. Следующий стартует только после exit процесса. */
const MAX_EXPORT_JOBS = 1;
const CPU_HANDOFF_MS = 80;
const GPU_HANDOFF_MS = 380;
const INTER_FILE_DELAY_MS = GPU_HANDOFF_MS;
const FFMPEG_EXIT_WAIT_MS = 8000;
const PROGRESS_INTERVAL_MS = 500;
const MIN_OUTPUT_BYTES = 64;

function outputContainer(encoderKey) {
  return encoderKey === 'prores' ? 'mov' : 'mp4';
}

function outputExtension(encoderKey) {
  return `.${outputContainer(encoderKey)}`;
}

/** Windows и «Кино и ТВ» показывают картинку только при avc1/hvc1, не при сыром h264 в .mov. */
function withPlayerCompatibleTags(encoderKey, videoOptions) {
  const opts = Array.isArray(videoOptions) ? [...videoOptions] : [];
  if (!opts.includes('-tag:v')) {
    if (encoderKey === 'h264') opts.push('-tag:v', 'avc1');
    if (encoderKey === 'h265') opts.push('-tag:v', 'hvc1');
  }
  return opts;
}

function encodePaceSpeed(plan) {
  const usage = (plan && plan.resourceUsage) || 'low';
  if (plan && plan.usingGpu) {
    if (usage === 'low' || usage === 'cpu') return ENCODE_PACE_SPEED;
    if (usage === 'high' || usage === 'gpu') return GPU_PACE_HIGH;
    return GPU_PACE_BALANCED;
  }
  return ENCODE_PACE_SPEED;
}

function paceGlobalArgs(plan) {
  return [
    '-readrate', String(encodePaceSpeed(plan)),
    '-readrate_initial_burst', '0'
  ];
}

function handoffDelayMs(plan) {
  return plan && plan.usingGpu ? GPU_HANDOFF_MS : CPU_HANDOFF_MS;
}

async function waitForFfmpegExit(command, timeoutMs = FFMPEG_EXIT_WAIT_MS) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const proc = command && command.ffmpegProc;
    if (!proc) return;
    if (proc.killed || proc.exitCode != null || proc.signalCode != null) return;
    await sleep(40);
  }
}

function prefixed(prefix, name) {
  return prefix ? `${prefix}${name}` : name;
}

/** Выше этого граф уходит в файл через -filter_complex_script, а не в argv. */
const FILTER_SCRIPT_THRESHOLD = 8000;

function isCommandTooLong(err) {
  if (!err) return false;
  if (err.code === 'ENAMETOOLONG') return true;
  return /ENAMETOOLONG/i.test(String(err.message || ''));
}

function isUnknownFfmpegOption(err) {
  const message = String((err && err.message) || '');
  return /Error splitting the argument list/i.test(message) || /Unrecognized option/i.test(message);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** Пресеты кодеков. H.264/H.265 — MP4 для Windows, ProRes — MOV. */
const ENCODERS = {
  auto: {
    label: 'Авто — HEVC на видеокарте, иначе H.264'
  },
  h264: {
    label: 'H.264',
    pixelFormat: 'yuv420p',
    audioBitrate: '96k',
    extraOptions: ['-movflags', '+faststart']
  },
  h265: {
    label: 'H.265 / HEVC',
    pixelFormat: 'yuv420p',
    audioBitrate: '96k',
    extraOptions: ['-movflags', '+faststart']
  },
  prores: {
    label: 'ProRes 422 HQ — максимальное качество',
    pixelFormat: 'yuv422p10le',
    videoOptions: ['-c:v', 'prores_ks', '-profile:v', '3', '-vendor', 'apl0'],
    audioOptions: ['-c:a', 'pcm_s16le'],
    extraOptions: []
  }
};

const EXPORT_MODES = {
  auto: { label: 'Авто — баланс качества, скорости и размера' },
  fast: { label: 'Быстрый — hardware preset, нормальное качество' },
  balanced: { label: 'Баланс — качество, размер и скорость' },
  quality: { label: 'Макс. качество — без медленных CPU-пресетов' }
};

const RESOURCE_MODES = {
  low: { label: 'Низкая — минимум нагрузки, стабильность' },
  balanced: { label: 'Баланс — один encode, умеренные потоки' },
  high: { label: 'Высокая — быстрее фильтры, всё ещё 1 encode' }
};

/** Размер итогового кадра. */
const FRAME_PRESETS = {
  square1080: { label: '1080×1080 — квадрат', width: 1080, height: 1080 },
  vertical1080: { label: '1080×1920 — вертикаль', width: 1080, height: 1920 },
  horizontal1080: { label: '1920×1080 — горизонталь', width: 1920, height: 1080 },
  source: { label: 'Как у исходника', width: null, height: null }
};

/** Как исходник ложится в кадр, если пропорции не совпадают. */
const FIT_MODES = {
  cover: { label: 'Заполнить кадр (обрезать лишнее)' },
  contain: { label: 'Вписать целиком (чёрные поля)' }
};

/**
 * Раскладка split-screen. Сдвиги — в процентах от ширины холста (1080×1080
 * по умолчанию). Нулевой сдвиг ставит центр исходника в центр своей половины.
 */
const SPLIT_DEFAULTS = {
  leftShare: 50,
  feather: 48,
  leftZoom: 1,
  leftOffset: 0,
  rightZoom: 1.8,
  rightOffset: 0
};

const DEFAULTS = {
  percent: 90,
  encoder: 'auto',
  exportMode: 'auto',
  resourceUsage: 'balanced',
  accel: 'hybrid',
  overlayOpacity: 100,
  outputPrefix: 'es',
  frame: 'square1080',
  fit: 'cover',
  split: SPLIT_DEFAULTS
};

/** Старые подписи нагрузки: оставлены как синонимы resourceUsage. */
const ACCEL_MODES = {
  hybrid: { label: RESOURCE_MODES.balanced.label },
  cpu: { label: 'Только процессор (если карта недоступна)' },
  gpu: { label: RESOURCE_MODES.high.label }
};

const GPU_H264 = [
  { id: 'h264_nvenc', vendor: 'NVIDIA NVENC', extras: [['-gpu', '0'], ['-gpu', '1'], []] },
  { id: 'h264_amf', vendor: 'AMD AMF', extras: [[]] },
  { id: 'h264_qsv', vendor: 'Intel Quick Sync', extras: [[]] },
  { id: 'h264_videotoolbox', vendor: 'Apple VideoToolbox', extras: [[]] }
];

const GPU_H265 = [
  { id: 'hevc_nvenc', vendor: 'NVIDIA NVENC', extras: [['-gpu', '0'], ['-gpu', '1'], []] },
  { id: 'hevc_amf', vendor: 'AMD AMF', extras: [[]] },
  { id: 'hevc_qsv', vendor: 'Intel Quick Sync', extras: [[]] },
  { id: 'hevc_videotoolbox', vendor: 'Apple VideoToolbox', extras: [[]] }
];

// ---------------------------------------------------------------------------
// Пути к бинарникам FFmpeg / FFprobe
// ---------------------------------------------------------------------------

/** Внутри упакованного asar бинарники лежат в app.asar.unpacked. */
function unpackedPath(binaryPath) {
  if (typeof binaryPath !== 'string' || !binaryPath) return null;
  return binaryPath.replace(/app\.asar([\\/])/, 'app.asar.unpacked$1');
}

function optionalRequire(moduleName) {
  try {
    return require(moduleName);
  } catch (err) {
    return null;
  }
}

const IS_WINDOWS = process.platform === 'win32';

function binaryFileName(base) {
  return IS_WINDOWS ? `${base}.exe` : base;
}

/**
 * Все места, где в установленном приложении может лежать ffmpeg/ffprobe:
 * распакованный asar, resources, node_modules и папка vendor.
 */
function binaryCandidates(candidate, base) {
  const list = [];
  const push = (file) => {
    if (file && !list.includes(file)) list.push(file);
  };
  push(unpackedPath(candidate));
  push(candidate);

  const name = binaryFileName(base);
  const pkg = `${base}-static`;
  const arch = process.arch === 'ia32' ? 'ia32' : process.arch === 'arm64' ? 'arm64' : 'x64';
  const roots = [];
  if (process.resourcesPath) {
    roots.push(path.join(process.resourcesPath, 'app.asar.unpacked'));
    roots.push(process.resourcesPath);
  }
  roots.push(__dirname);
  roots.forEach((root) => {
    push(path.join(root, 'node_modules', pkg, name));
    push(path.join(root, 'node_modules', pkg, 'bin', process.platform, arch, name));
    push(path.join(root, 'vendor', 'ffmpeg', name));
  });
  return list;
}

function resolveBinary(candidate, base) {
  for (const file of binaryCandidates(candidate, base)) {
    try {
      if (fs.existsSync(file)) return file;
    } catch (err) {
      // недоступный путь — пробуем следующий
    }
  }
  return binaryFileName(base);
}

const ffmpegStatic = optionalRequire('ffmpeg-static');
const ffprobeStatic = optionalRequire('ffprobe-static');

const ffmpegPath = resolveBinary(ffmpegStatic, 'ffmpeg');
const ffprobePath = resolveBinary(ffprobeStatic && ffprobeStatic.path, 'ffprobe');

/** ffprobe в сборке может отсутствовать — тогда читаем файлы через ffmpeg. */
let ffprobeWorks = null;

function ffprobeAvailable() {
  if (ffprobeWorks === null) {
    try {
      execFileSync(ffprobePath, ['-version'], { stdio: 'ignore', timeout: 15000 });
      ffprobeWorks = true;
    } catch (err) {
      ffprobeWorks = false;
    }
  }
  return ffprobeWorks;
}

ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobePath);

// ---------------------------------------------------------------------------
// Видеокарта: декодирование и кодирование. Фильтры остаются на CPU.
// ---------------------------------------------------------------------------

class GpuUnavailableError extends Error {
  constructor(cause) {
    super(cause && cause.message ? cause.message : 'GPU-кодирование недоступно');
    this.name = 'GpuUnavailableError';
    this.gpuFallback = true;
  }
}

function ffmpegCli(args, options = {}) {
  try {
    return execFileSync(ffmpegPath, args, {
      encoding: 'utf8',
      timeout: options.timeout || 15000,
      maxBuffer: 4 * 1024 * 1024,
      stdio: options.stdio || ['ignore', 'pipe', 'pipe']
    });
  } catch (err) {
    const stderr = err && err.stderr ? String(err.stderr) : '';
    const stdout = err && err.stdout ? String(err.stdout) : '';
    err.combined = `${stdout}\n${stderr}`.trim();
    throw err;
  }
}

function parseEncoderIds(text) {
  const ids = new Set();
  String(text || '').split('\n').forEach((line) => {
    const match = line.match(/^\s*[A-Za-z.]+\s+(\S+)/);
    if (match) ids.add(match[1]);
  });
  return ids;
}

function parseHwaccels(text) {
  return String(text || '')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line && !/hardware acceleration/i.test(line));
}

function probeEncoder(id, extra) {
  const tmp = path.join(os.tmpdir(), `shorts-gpu-probe-${process.pid}-${id}.mp4`);
  try {
    ffmpegCli(
      [
        '-hide_banner', '-loglevel', 'error', '-y',
        '-f', 'lavfi', '-i', 'color=c=black:s=256x256:r=15:d=0.4',
        '-pix_fmt', 'yuv420p',
        '-c:v', id, ...(extra || []),
        '-frames:v', '4',
        tmp
      ],
      { timeout: 12000, stdio: ['ignore', 'ignore', 'pipe'] }
    );
    return { ok: true };
  } catch (err) {
    return { ok: false, error: shortenFfmpegError(err.combined || err.message) };
  } finally {
    try {
      if (fs.existsSync(tmp)) fs.unlinkSync(tmp);
    } catch (err) {
      /* временный файл */
    }
  }
}

function pickGpuEncoder(candidates, compiledIds) {
  let lastError = null;
  for (const candidate of candidates) {
    if (!compiledIds.has(candidate.id)) continue;
    const extras = candidate.extras && candidate.extras.length ? candidate.extras : [[]];
    for (const extra of extras) {
      const probe = probeEncoder(candidate.id, extra);
      if (probe.ok) {
        return {
          encoder: { id: candidate.id, vendor: candidate.vendor, extra },
          error: null
        };
      }
      lastError = `${candidate.id}: ${probe.error}`;
    }
  }
  return { encoder: null, error: lastError };
}

let hardwareCache = null;

/**
 * Какие GPU-кодеки реально отвечают на тестовый кадр, а не просто
 * скомпилированы в бинарник. На ноутбуке с Intel + NVIDIA NVENC часто
 * открывается только с `-gpu 1`, а Quick Sync — на встроенной карте.
 */
function detectHardware() {
  if (hardwareCache) return hardwareCache;

  let encoderText = '';
  let accelText = '';
  try {
    encoderText = ffmpegCli(['-hide_banner', '-encoders'], { stdio: ['ignore', 'pipe', 'ignore'] });
  } catch (err) {
    encoderText = err.combined || '';
  }
  try {
    accelText = ffmpegCli(['-hide_banner', '-hwaccels'], { stdio: ['ignore', 'pipe', 'ignore'] });
  } catch (err) {
    accelText = err.combined || '';
  }

  const ids = parseEncoderIds(encoderText);
  const accels = parseHwaccels(accelText);
  const wanted = [...GPU_H264, ...GPU_H265].map((item) => item.id);
  const compiledGpu = wanted.filter((id) => ids.has(id));

  const h264 = pickGpuEncoder(GPU_H264, ids);
  const h265 = pickGpuEncoder(GPU_H265, ids);

  const preferredAccel = {
    win32: ['d3d11va', 'cuda', 'dxva2', 'qsv'],
    linux: ['vaapi', 'cuda', 'vdpau'],
    darwin: ['videotoolbox']
  }[process.platform] || [];

  hardwareCache = {
    h264: h264.encoder,
    h265: h265.encoder,
    hwaccel: preferredAccel.find((name) => accels.includes(name)) || null,
    accels,
    compiledGpu,
    probeError: (h264.encoder ? null : h264.error) || (h265.encoder ? null : h265.error) || null,
    cores: Math.max(1, (os.cpus() || []).length || 4)
  };
  return hardwareCache;
}

function threadBudget(resourceUsage, coreCount, usingGpu) {
  const cores = Math.max(1, coreCount || (os.cpus() || []).length || 4);
  if (resourceUsage === 'low' || resourceUsage === 'cpu') {
    return { cores, filterThreads: 1, encodeThreads: resourceUsage === 'cpu' ? Math.max(1, Math.min(4, Math.ceil(cores / 3))) : 1 };
  }
  if (resourceUsage === 'high' || resourceUsage === 'gpu') {
    const n = Math.max(2, Math.min(usingGpu ? 4 : 6, Math.ceil(cores / 2)));
    return { cores, filterThreads: Math.min(4, n), encodeThreads: n };
  }
  const n = Math.max(2, Math.min(usingGpu ? 2 : 4, Math.floor(cores / 3) || 2));
  return { cores, filterThreads: Math.min(2, n), encodeThreads: n };
}

function mapAccelToResource(accel) {
  if (accel === 'gpu' || accel === 'high') return 'high';
  if (accel === 'cpu' || accel === 'low') return 'low';
  return 'balanced';
}

function normalizeExportMode(value) {
  if (value === 'max' || value === 'max_quality') return 'quality';
  return EXPORT_MODES[value] ? value : DEFAULTS.exportMode;
}

function normalizeResourceUsage(value) {
  if (RESOURCE_MODES[value]) return value;
  return mapAccelToResource(value);
}

function normalizeExportOptions(accelOrOptions) {
  if (accelOrOptions && typeof accelOrOptions === 'object' && !Array.isArray(accelOrOptions)) {
    const accel = accelOrOptions.accel;
    return {
      exportMode: normalizeExportMode(accelOrOptions.exportMode),
      resourceUsage: normalizeResourceUsage(accelOrOptions.resourceUsage || accel),
      forceCpu: Boolean(accelOrOptions.forceCpu) || accel === 'cpu',
      target: accelOrOptions.target || null
    };
  }
  const accel = String(accelOrOptions || DEFAULTS.accel);
  return {
    exportMode: DEFAULTS.exportMode,
    resourceUsage: mapAccelToResource(accel),
    forceCpu: accel === 'cpu',
    target: null
  };
}

/** Авто никогда не берёт software HEVC — libx265 легко кладёт CPU в 100%. */
function resolveEncoderKey(requested, hardware) {
  if (requested === 'prores' || requested === 'h264' || requested === 'h265') return requested;
  if (hardware && hardware.h265) return 'h265';
  return 'h264';
}

function pixelCount(width, height) {
  return Math.max(1, Number(width) || 1080) * Math.max(1, Number(height) || 1080);
}

function perceptualCq(encoderKey, exportMode, width, height) {
  const mode = exportMode === 'auto' ? 'balanced' : exportMode;
  const base = encoderKey === 'h265'
    ? { fast: 30, balanced: 26, quality: 22 }[mode] || 26
    : { fast: 26, balanced: 23, quality: 20 }[mode] || 23;
  const pixels = pixelCount(width, height);
  const p1080 = 1920 * 1080;
  let adj = 0;
  if (pixels < p1080 * 0.55) adj += 1;
  else if (pixels > p1080 * 1.8) adj -= 1;
  return clamp(base + adj, 16, 34);
}

function audioBitrateForMode(exportMode) {
  if (exportMode === 'fast') return '80k';
  if (exportMode === 'quality') return '128k';
  return '96k';
}

function softwareVideoOptions(encoderKey, exportMode, threads, cq) {
  const mode = exportMode === 'auto' ? 'balanced' : exportMode;
  if (encoderKey === 'h265') {
    const preset = mode === 'quality' ? 'fast' : 'veryfast';
    return [
      '-c:v', 'libx265', '-preset', preset, '-crf', String(cq), '-tag:v', 'hvc1',
      '-x265-params', 'log-level=error',
      '-threads', String(threads)
    ];
  }
  const preset = mode === 'quality' ? 'fast' : 'veryfast';
  const x264 = mode === 'quality'
    ? 'ref=2:bframes=2:rc-lookahead=20:scenecut=40'
    : 'ref=1:bframes=0:rc-lookahead=10:sync-lookahead=0:scenecut=0';
  return [
    '-c:v', 'libx264', '-preset', preset, '-crf', String(cq), '-profile:v', 'high',
    '-tag:v', 'avc1',
    '-x264-params', x264,
    '-threads', String(threads)
  ];
}

function gpuIndexFromExtra(extra) {
  const list = Array.isArray(extra) ? extra : [];
  const idx = list.indexOf('-gpu');
  if (idx >= 0 && list[idx + 1] != null) return list[idx + 1];
  return null;
}

function hardwareVideoOptions(gpu, encoderKey, exportMode, cq) {
  const mode = exportMode === 'auto' ? 'balanced' : exportMode;
  const id = gpu && gpu.id;
  const gpuIndex = gpuIndexFromExtra(gpu && gpu.extra);
  const hevcTag = encoderKey === 'h265' ? ['-tag:v', 'hvc1'] : [];

  if (id === 'h264_nvenc' || id === 'hevc_nvenc') {
    const preset = mode === 'fast' ? 'p1' : mode === 'quality' ? 'p5' : 'p4';
    const opts = [];
    if (gpuIndex != null) opts.push('-gpu', String(gpuIndex));
    opts.push('-c:v', id, '-preset', preset, '-tune', mode === 'fast' ? 'll' : 'hq');
    opts.push('-rc', 'vbr', '-cq', String(cq), '-b:v', '0');
    if (mode === 'fast') opts.push('-rc-lookahead', '0', '-bf', '0');
    else if (mode === 'quality') opts.push('-spatial-aq', '1', '-temporal-aq', '1', '-rc-lookahead', '16', '-bf', '2');
    else opts.push('-spatial-aq', '1', '-rc-lookahead', '8', '-bf', '2');
    opts.push('-async_depth', '2');
    return withPlayerCompatibleTags(encoderKey, opts.concat(hevcTag));
  }

  if (id === 'h264_amf' || id === 'hevc_amf') {
    const quality = mode === 'fast' ? 'speed' : mode === 'quality' ? 'quality' : 'balanced';
    return withPlayerCompatibleTags(encoderKey, [
      '-c:v', id, '-quality', quality, '-rc', 'cqp', '-qp_i', String(cq), '-qp_p', String(cq + 2),
      ...hevcTag
    ]);
  }

  if (id === 'h264_qsv' || id === 'hevc_qsv') {
    const preset = mode === 'fast' ? 'veryfast' : mode === 'quality' ? 'medium' : 'fast';
    return withPlayerCompatibleTags(encoderKey, [
      '-c:v', id, '-preset', preset, '-global_quality', String(cq), ...hevcTag
    ]);
  }

  if (id === 'h264_videotoolbox' || id === 'hevc_videotoolbox') {
    const q = mode === 'fast' ? 55 : mode === 'quality' ? 72 : 65;
    const opts = ['-c:v', id, '-q:v', String(q)];
    if (encoderKey === 'h264') opts.push('-profile:v', 'high');
    return withPlayerCompatibleTags(encoderKey, opts.concat(hevcTag));
  }

  return withPlayerCompatibleTags(encoderKey, ['-c:v', id, ...(gpu.extra || []), ...hevcTag]);
}

function estimateOutputBytes({ width, height, fps, duration, encoderKey, exportMode }) {
  const cq = perceptualCq(encoderKey, exportMode, width, height);
  const bpp = encoderKey === 'h265'
    ? 0.042 + (28 - cq) * 0.0035
    : 0.065 + (26 - cq) * 0.005;
  const video = pixelCount(width, height) * Math.max(1, fps || 30) * Math.max(0.1, duration || 1) * bpp / 8;
  const audioBps = (exportMode === 'quality' ? 16000 : 12000) * Math.max(0.1, duration || 1);
  return Math.max(MIN_OUTPUT_BYTES, Math.round(video + audioBps));
}

function describeEncodeWork({ overlay, closeup, source, shorts, target }) {
  const scale = Boolean(
    source && target && (source.width !== target.width || source.height !== target.height)
  ) || Boolean(shorts && target && (shorts.width !== target.width || shorts.height !== target.height));
  const fpsConvert = Boolean(source && target && needsFpsConvert(target.fps, source.fps))
    || Boolean(shorts && target && needsFpsConvert(target.fps, shorts.fps));
  return {
    mustEncodeVideo: true,
    streamCopy: false,
    scale,
    fpsConvert,
    overlay: Boolean(overlay),
    split: Boolean(closeup),
    keepSourceFps: Boolean(source && target && !needsFpsConvert(target.fps, source.fps)),
    reason: 'вставка Shorts в середину всегда собирает новый видеопоток одним ffmpeg'
  };
}

/**
 * Hardware encoder если доступен, CQ/CRF по разрешению, CPU только на фильтры.
 */
function resolveEncodePlan(encoderKey, accelOrOptions, hardware) {
  const options = normalizeExportOptions(accelOrOptions);
  const hw = hardware || {};
  const family = resolveEncoderKey(encoderKey, hw);
  const cpu = ENCODERS[family] || ENCODERS.h264;
  const wantGpu = !options.forceCpu && family !== 'prores';
  const gpu = family === 'h265' ? hw.h265 : family === 'h264' ? hw.h264 : null;
  const usingGpu = Boolean(wantGpu && gpu);
  const threads = threadBudget(options.resourceUsage, hw.cores, usingGpu);
  const width = options.target && options.target.width;
  const height = options.target && options.target.height;
  const cq = perceptualCq(family, options.exportMode, width, height);
  const audioOptions = family === 'prores'
    ? ENCODERS.prores.audioOptions
    : ['-c:a', 'aac', '-b:a', audioBitrateForMode(options.exportMode)];
  const extraOptions = (cpu.extraOptions && cpu.extraOptions.length) ? cpu.extraOptions : ['-movflags', '+faststart'];
  const pace = family !== 'prores' && (options.resourceUsage === 'low' || usingGpu);

  if (family === 'prores') {
    return {
      encoderKey: family,
      exportMode: options.exportMode,
      resourceUsage: options.resourceUsage,
      label: `${cpu.label} — CPU`,
      encoderName: 'prores_ks',
      pixelFormat: cpu.pixelFormat,
      videoOptions: [...cpu.videoOptions, '-threads', String(threads.encodeThreads)],
      audioOptions,
      extraOptions: cpu.extraOptions || [],
      hwaccel: null,
      usingGpu: false,
      vendor: null,
      threads,
      pace: false,
      cq: null
    };
  }

  if (usingGpu) {
    return {
      encoderKey: family,
      exportMode: options.exportMode,
      resourceUsage: options.resourceUsage,
      label: `${gpu.vendor} ${family === 'h265' ? 'HEVC' : 'H.264'} · ${EXPORT_MODES[options.exportMode].label}`,
      encoderName: gpu.id,
      pixelFormat: 'yuv420p',
      videoOptions: hardwareVideoOptions(gpu, family, options.exportMode, cq),
      audioOptions,
      extraOptions,
      hwaccel: null,
      usingGpu: true,
      vendor: gpu.vendor,
      threads,
      pace,
      cq
    };
  }

  const reason = options.forceCpu
    ? 'выбран процессор'
    : hw.probeError
      ? `видеокарта не приняла тест (${hw.probeError})`
      : 'видеокарта недоступна';
  return {
    encoderKey: family,
    exportMode: options.exportMode,
    resourceUsage: options.resourceUsage,
    label: `${ENCODERS[family].label} ${options.exportMode} · ${reason}, ${threads.encodeThreads} из ${threads.cores} потоков`,
    encoderName: family === 'h265' ? 'libx265' : 'libx264',
    pixelFormat: 'yuv420p',
    videoOptions: withPlayerCompatibleTags(family, softwareVideoOptions(family, options.exportMode, threads.encodeThreads, cq)),
    audioOptions,
    extraOptions,
    hwaccel: null,
    usingGpu: false,
    vendor: null,
    threads,
    pace,
    cq
  };
}

// ---------------------------------------------------------------------------
// Вспомогательные функции
// ---------------------------------------------------------------------------

class ProcessingCancelledError extends Error {
  constructor() {
    super('Обработка остановлена пользователем');
    this.name = 'ProcessingCancelledError';
    this.cancelled = true;
  }
}

function isVideoFile(fileName) {
  return VIDEO_EXTENSIONS.includes(path.extname(fileName).toLowerCase());
}

/** Натуральная сортировка: video2.mp4 идёт раньше video10.mp4. */
function naturalCompare(a, b) {
  return a.localeCompare(b, 'ru', { numeric: true, sensitivity: 'base' });
}

/**
 * Список видеофайлов в папке (без рекурсии).
 * Файлы, которые совпадают с шаблоном результата (esN.mp4 / esN.mov), игнорируются —
 * иначе повторный запуск с той же папкой на входе и выходе зациклится.
 */
function listVideoFiles(directory, options = {}) {
  const prefix = options.outputPrefix || DEFAULTS.outputPrefix;
  const skipOutputNames = Boolean(options.skipOutputNames);
  const outputPattern = new RegExp(`^${escapeRegExp(prefix)}\\d+\\.(mov|mp4)$`, 'i');

  const entries = fs.readdirSync(directory, { withFileTypes: true });
  return entries
    .filter((entry) => entry.isFile() || entry.isSymbolicLink())
    .map((entry) => entry.name)
    .filter((name) => isVideoFile(name))
    .filter((name) => !(skipOutputNames && outputPattern.test(name)))
    .sort(naturalCompare)
    .map((name) => path.join(directory, name));
}

function parseFrameRate(value, fallback = 30) {
  if (!value || typeof value !== 'string') return fallback;
  const [num, den] = value.split('/');
  const numerator = Number(num);
  const denominator = den === undefined ? 1 : Number(den);
  if (!Number.isFinite(numerator) || !Number.isFinite(denominator) || denominator === 0) return fallback;
  const fps = numerator / denominator;
  if (!Number.isFinite(fps) || fps <= 0 || fps > 240) return fallback;
  return Math.round(fps * 1000) / 1000;
}

function readRotation(stream) {
  let rotation = 0;
  if (stream.tags && stream.tags.rotate !== undefined) rotation = Number(stream.tags.rotate);
  if (stream.rotation !== undefined) rotation = Number(stream.rotation);
  if (Array.isArray(stream.side_data_list)) {
    const side = stream.side_data_list.find((item) => item && item.rotation !== undefined);
    if (side) rotation = Number(side.rotation);
  }
  if (!Number.isFinite(rotation)) rotation = 0;
  return ((Math.round(rotation) % 360) + 360) % 360;
}

/** FFmpeg печатает баннер сборки — в логе нужна только суть ошибки. */
function shortenFfmpegError(message) {
  const lines = String(message || '')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line) => !/^(ff(mpeg|probe) version|built with|configuration:|lib[a-z]+\s+\d)/i.test(line));
  const meaningful = lines.filter((line) => !/^Copyright/i.test(line));
  const last = meaningful[meaningful.length - 1] || lines[0] || 'неизвестная ошибка';
  const unrecognized = meaningful.find((line) => /Unrecognized option/i.test(line));
  if (unrecognized && unrecognized !== last) return `${unrecognized} ${last}`.slice(0, 400);
  return last.slice(0, 400);
}

/** Разбор вывода `ffmpeg -i file` — резерв на случай отсутствия ffprobe. */
function parseFfmpegProbe(text) {
  const lines = String(text || '').split(/\r?\n/);
  const videoLine = lines.find((line) => /:\s*Video:/.test(line)) || '';
  const audioLine = lines.find((line) => /:\s*Audio:/.test(line)) || '';
  const durationMatch = String(text || '').match(/Duration:\s*(\d+):(\d\d):(\d\d(?:\.\d+)?)/);
  const duration = durationMatch
    ? Number(durationMatch[1]) * 3600 + Number(durationMatch[2]) * 60 + Number(durationMatch[3])
    : 0;
  const size = videoLine.match(/(\d{2,5})x(\d{2,5})/);
  const fpsMatch = videoLine.match(/([\d.]+)\s+fps/) || videoLine.match(/([\d.]+)\s+tbr/);
  const displayMatrix = String(text || '').match(/rotation of\s*(-?[\d.]+)\s*degrees/i);
  const rotateTag = String(text || '').match(/rotate\s*:\s*(-?[\d.]+)/i);
  let rotation = 0;
  if (displayMatrix) rotation = Number(displayMatrix[1]);
  else if (rotateTag) rotation = Number(rotateTag[1]);
  if (!Number.isFinite(rotation)) rotation = 0;
  const videoCodec = (videoLine.match(/Video:\s*([A-Za-z0-9_]+)/) || [])[1] || null;
  const audioCodec = (audioLine.match(/Audio:\s*([A-Za-z0-9_]+)/) || [])[1] || null;
  const langMatch = audioLine.match(/Stream #\d+:\d+(?:\[[^\]]*\])?\(([A-Za-z]{2,3})\)/);
  return {
    hasVideo: Boolean(videoLine && size),
    hasAudio: Boolean(audioLine),
    width: size ? Number(size[1]) : null,
    height: size ? Number(size[2]) : null,
    rotation: ((Math.round(rotation) % 360) + 360) % 360,
    duration: Number.isFinite(duration) ? duration : 0,
    fps: fpsMatch ? Number(fpsMatch[1]) : null,
    videoCodec,
    audioCodec,
    audioLanguage: langMatch && langMatch[1].toLowerCase() !== 'und' ? langMatch[1].toLowerCase() : null
  };
}

function runFfmpegProbe(file) {
  try {
    return String(
      execFileSync(ffmpegPath, ['-hide_banner', '-i', file], {
        encoding: 'utf8',
        timeout: 60000,
        stdio: ['ignore', 'pipe', 'pipe']
      }) || ''
    );
  } catch (err) {
    const text = `${(err && err.stderr) || ''}${(err && err.stdout) || ''}`;
    if (text.trim()) return text;
    throw err;
  }
}

/** То же, что probeMedia, но без ffprobe — только силами ffmpeg. */
async function probeMediaViaFfmpeg(file) {
  let text = '';
  try {
    text = runFfmpegProbe(file);
  } catch (err) {
    throw new Error(
      `Не удалось прочитать файл (${path.basename(file)}): ${shortenFfmpegError(err && err.message)}`
    );
  }
  const parsed = parseFfmpegProbe(text);
  if (!parsed.hasVideo) {
    throw new Error(`В файле нет видеодорожки: ${path.basename(file)}`);
  }
  const swapped = parsed.rotation === 90 || parsed.rotation === 270;
  const width = Number(swapped ? parsed.height : parsed.width);
  const height = Number(swapped ? parsed.width : parsed.height);
  if (!Number.isFinite(width) || !Number.isFinite(height) || width < 2 || height < 2) {
    throw new Error(`Некорректные размеры кадра: ${path.basename(file)}`);
  }
  return {
    file,
    width: Math.floor(width / 2) * 2,
    height: Math.floor(height / 2) * 2,
    rotation: parsed.rotation,
    duration: parsed.duration,
    fps: parsed.fps && parsed.fps > 0 && parsed.fps <= 240 ? Math.round(parsed.fps * 1000) / 1000 : 30,
    hasAudio: parsed.hasAudio,
    videoCodec: parsed.videoCodec || 'unknown',
    codecTag: '',
    audioCodec: parsed.hasAudio ? parsed.audioCodec || 'unknown' : null
  };
}

/**
 * Метаданные файла. Если ffprobe отсутствует или не запускается,
 * файл всё равно читается — через ffmpeg.
 */
async function probeMedia(file) {
  if (!ffprobeAvailable()) return probeMediaViaFfmpeg(file);
  try {
    return await probeMediaWithFfprobe(file);
  } catch (err) {
    const message = String((err && err.message) || '');
    if (/ENOENT|spawn|EACCES|not recognized|не является внутренней/i.test(message)) {
      ffprobeWorks = false;
      return probeMediaViaFfmpeg(file);
    }
    throw err;
  }
}

/** Метаданные файла: размеры (с учётом поворота), длительность, fps, наличие дорожек. */
function probeMediaWithFfprobe(file) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(file, (err, data) => {
      if (err) {
        reject(
          new Error(`Не удалось прочитать файл (${path.basename(file)}): ${shortenFfmpegError(err.message)}`)
        );
        return;
      }

      const streams = Array.isArray(data.streams) ? data.streams : [];
      const videoStream = streams.find(
        (s) => s.codec_type === 'video' && !(s.disposition && s.disposition.attached_pic)
      );
      const audioStream = streams.find((s) => s.codec_type === 'audio');

      if (!videoStream) {
        reject(new Error(`В файле нет видеодорожки: ${path.basename(file)}`));
        return;
      }

      const rotation = readRotation(videoStream);
      const swapped = rotation === 90 || rotation === 270;
      const width = Number(swapped ? videoStream.height : videoStream.width);
      const height = Number(swapped ? videoStream.width : videoStream.height);

      const duration =
        Number(data.format && data.format.duration) ||
        Number(videoStream.duration) ||
        0;

      if (!Number.isFinite(width) || !Number.isFinite(height) || width < 2 || height < 2) {
        reject(new Error(`Некорректные размеры кадра: ${path.basename(file)}`));
        return;
      }

      resolve({
        file,
        width: Math.floor(width / 2) * 2,
        height: Math.floor(height / 2) * 2,
        rotation,
        duration: Number.isFinite(duration) ? duration : 0,
        fps: parseFrameRate(videoStream.r_frame_rate, 30),
        hasAudio: Boolean(audioStream),
        videoCodec: videoStream.codec_name || 'unknown',
        codecTag: videoStream.codec_tag_string || '',
        audioCodec: audioStream ? audioStream.codec_name || 'unknown' : null
      });
    });
  });
}

function formatDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00:00';
  const total = Math.floor(seconds);
  const hh = String(Math.floor(total / 3600)).padStart(2, '0');
  const mm = String(Math.floor((total % 3600) / 60)).padStart(2, '0');
  const ss = String(total % 60).padStart(2, '0');
  return `${hh}:${mm}:${ss}`;
}

/** "00:01:23.45" -> 83.45 */
function timemarkToSeconds(timemark) {
  if (typeof timemark !== 'string') return 0;
  const parts = timemark.split(':');
  if (parts.length !== 3) return 0;
  const hours = Number(parts[0]);
  const minutes = Number(parts[1]);
  const seconds = parseFloat(parts[2]);
  if (![hours, minutes, seconds].every(Number.isFinite)) return 0;
  return hours * 3600 + minutes * 60 + seconds;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function safeUnlink(file) {
  try {
    if (file && fs.existsSync(file)) fs.unlinkSync(file);
  } catch (err) {
    /* файл может быть занят — не критично */
  }
}

// ---------------------------------------------------------------------------
// Построение графа фильтров
// ---------------------------------------------------------------------------

function lowerFfmpegPriority(command) {
  const proc = command && command.ffmpegProc;
  if (!proc || !Number.isInteger(proc.pid)) return;
  const levels = os.constants && os.constants.priority;
  if (!levels) return;
  try {
    os.setPriority(proc.pid, levels.PRIORITY_BELOW_NORMAL);
  } catch (err) {
    try {
      os.setPriority(proc.pid, levels.PRIORITY_LOW);
    } catch (err2) {
      /* нет прав менять приоритет — не критично */
    }
  }
}

function chooseOutputFps(sourceFps) {
  if (!Number.isFinite(sourceFps) || sourceFps <= 0) return MAX_OUTPUT_FPS;
  return clamp(sourceFps, 1, MAX_KEEP_FPS);
}

function needsFpsConvert(targetFps, inputFps) {
  return !(Number.isFinite(inputFps) && Math.abs(inputFps - targetFps) < 0.08);
}

function filterChain(...parts) {
  return parts.filter(Boolean).join(',');
}

/** Вписывание кадра в холст: обрезать по краям либо добавить чёрные поля. */
function fitStep(target, src) {
  if (src && src.width === target.width && src.height === target.height) return '';
  if (target.fit === 'contain') {
    return (
      `scale=${target.width}:${target.height}:force_original_aspect_ratio=decrease:flags=${SCALE_FLAGS},` +
      `pad=${target.width}:${target.height}:-1:-1:color=black`
    );
  }
  return (
    `scale=${target.width}:${target.height}:force_original_aspect_ratio=increase:flags=${SCALE_FLAGS},` +
    `crop=${target.width}:${target.height}`
  );
}

function videoSegmentFilter(inputLabel, outputLabel, target, inputFps, srcSize, duration) {
  const trim = Number.isFinite(duration) && duration > 0
    ? `trim=duration=${duration.toFixed(3)},setpts=PTS-STARTPTS`
    : 'setpts=PTS-STARTPTS';
  return (
    `[${inputLabel}]${filterChain(
      trim,
      needsFpsConvert(target.fps, inputFps) ? `fps=${target.fps}` : '',
      fitStep(target, srcSize),
      'setsar=1',
      `format=${target.pixelFormat}`
    )}[${outputLabel}]`
  );
}

/** Один вход ролика: своя позиция и свой лимит, без хвоста предыдущего файла. */
function segmentInputOptions(start, duration) {
  const options = ['-accurate_seek', '-ss', Number.isFinite(start) && start > 0 ? start.toFixed(3) : '0'];
  if (Number.isFinite(duration) && duration > 0) options.push('-t', duration.toFixed(3));
  return options;
}

/**
 * Замороженные числа одного Shorts. Следующий ролик не должен увидеть
 * хвост 20%, playhead или длительность предыдущей операции.
 */
function isolateJobTimeline({ closeupStart, splitAt, duration, percent }) {
  return {
    closeupStart: Number(closeupStart) || 0,
    splitAt: Number(splitAt),
    duration: Number(duration),
    percent: Number(percent)
  };
}

const AUDIO_FORMAT_FILTER =
  `aformat=sample_fmts=fltp:sample_rates=${AUDIO_SAMPLE_RATE}:channel_layouts=${AUDIO_LAYOUT}`;

function audioSegmentFilter(inputLabel, outputLabel, duration) {
  const trim = Number.isFinite(duration) && duration > 0
    ? `atrim=duration=${duration.toFixed(3)},`
    : '';
  return (
    `[${inputLabel}]${trim}asetpts=PTS-STARTPTS,aresample=${AUDIO_SAMPLE_RATE}:first_pts=0,` +
    `${AUDIO_FORMAT_FILTER}[${outputLabel}]`
  );
}

/**
 * Тишина нужной длины. Источник строится прямо в графе фильтров:
 * отдельный вход с форматом lavfi fluent-ffmpeg не пропускает.
 */
function silentSegmentFilter(outputLabel, duration) {
  const seconds = Math.max(0.04, duration).toFixed(3);
  return (
    `anullsrc=r=${AUDIO_SAMPLE_RATE}:cl=${AUDIO_LAYOUT},atrim=duration=${seconds},` +
    `asetpts=PTS-STARTPTS,${AUDIO_FORMAT_FILTER}[${outputLabel}]`
  );
}

function evenRound(value) {
  return Math.max(2, Math.round(value / 2) * 2);
}

/**
 * Мягкая граница split-screen. Raised-cosine на полном кадре маски.
 * Без loop/eval: на ffmpeg 6.1 `geq=...:eval=init` ломает разбор опций.
 */
function buildFeatherMaskFilter({ width, height, fps, duration, feather, outputLabel }) {
  const denom = Math.max(1, feather - 1).toFixed(1);
  const ease = `0.5-0.5*cos(PI*clip(X/${denom},0,1))`;
  const maskDuration = Math.max(1, duration + 1).toFixed(3);
  const rate = Number.isFinite(fps) && fps > 0 ? fps : MAX_OUTPUT_FPS;
  return (
    `color=c=black:s=${width}x${height}:r=${rate}:d=${maskDuration},` +
      `format=gray,geq=lum='255*(${ease})'[${outputLabel}]`
  );
}

/** Приводит настройки раскладки к безопасным значениям. */
function normalizeSplit(config = {}) {
  const number = (value, fallback) => (Number.isFinite(Number(value)) ? Number(value) : fallback);
  return {
    leftShare: clamp(number(config.leftShare, SPLIT_DEFAULTS.leftShare), 20, 80),
    feather: clamp(Math.round(number(config.feather, SPLIT_DEFAULTS.feather)), 0, 200),
    // Зум меньше единицы оставил бы в кадре пустоту, поэтому нижняя граница — 1.
    leftZoom: clamp(number(config.leftZoom, SPLIT_DEFAULTS.leftZoom), 1, 4),
    rightZoom: clamp(number(config.rightZoom, SPLIT_DEFAULTS.rightZoom), 1, 4),
    leftOffset: clamp(number(config.leftOffset, SPLIT_DEFAULTS.leftOffset), -100, 100),
    rightOffset: clamp(number(config.rightOffset, SPLIT_DEFAULTS.rightOffset), -100, 100)
  };
}

/** Формат с альфой под глубину цвета итогового кодека. */
function alphaFormatFor(pixelFormat) {
  return /10le|12le/.test(pixelFormat) ? 'yuva444p10le' : 'yuva444p';
}

/**
 * Окно в видео, которое заполняет половину кадра.
 *
 * Сначала ролик масштабируется так, чтобы покрыть панель (как cover), затем
 * дополнительно на zoom, и из получившегося слоя вырезается панель со сдвигом.
 * Нулевой сдвиг — центр исходника в центре половины, как в примере 1080×1080.
 */
function coverWindow({ srcW, srcH, paneW, paneH, zoom, panPercent, canvasW }) {
  const scale = Math.max((paneW * zoom) / srcW, (paneH * zoom) / srcH);
  const scaledW = evenRound(srcW * scale);
  const scaledH = evenRound(srcH * scale);
  const panPx = (canvasW * panPercent) / 100;
  return {
    scaledW,
    scaledH,
    cropX: clamp(Math.round((scaledW - paneW) / 2 - panPx), 0, Math.max(0, scaledW - paneW)),
    cropY: clamp(Math.round((scaledH - paneH) / 2), 0, Math.max(0, scaledH - paneH))
  };
}

function coverFilter(label, src, paneW, paneH, zoom, panPercent, canvasW, outputLabel) {
  const window = coverWindow({
    srcW: src.width,
    srcH: src.height,
    paneW,
    paneH,
    zoom,
    panPercent,
    canvasW
  });
  const scale =
    window.scaledW === src.width && window.scaledH === src.height
      ? ''
      : `scale=${window.scaledW}:${window.scaledH}:flags=${SCALE_FLAGS},`;
  return `${label}${scale}crop=${paneW}:${paneH}:${window.cropX}:${window.cropY}[${outputLabel}]`;
}

/**
 * Смещение внутри второго видео: 0, duration, почти duration — это начало.
 * Иначе берём остаток от деления, чтобы таймлайн зацикливался.
 */
function wrapCloseupOffset(start, duration) {
  if (!Number.isFinite(start) || !Number.isFinite(duration) || duration <= 0) return 0;
  let offset = start % duration;
  if (offset < 0) offset += duration;
  // Только численный хвост float, без порога 20 мс: иначе playhead у конца
  // файла прыгает в 0 и начало крупного плана повторяется в следующем Shorts.
  if (offset < 1e-4 || duration - offset < 1e-4) return 0;
  return offset;
}

/**
 * Входы для правой половины: не с начала файла, а с playhead партии.
 *
 *   offset = 0              → одно зацикленное видео с нуля;
 *   remaining >= длительность результата → один кусок с -ss;
 *   иначе                   → хвост до конца, затем то же видео с начала (луп).
 */
function planCloseupInputs(closeup, startSec, neededSec) {
  const duration = closeup && closeup.duration ? closeup.duration : 0;
  const offset = wrapCloseupOffset(startSec, duration);
  const needed = Math.max(0.05, Number(neededSec) || 0);
  const remaining = duration - offset;
  const pad = 0.05;

  if (!closeup || !closeup.file) return { inputs: [], wrap: false, offset: 0, remaining, needed };

  if (offset === 0) {
    return {
      inputs: [{ file: closeup.file, options: ['-stream_loop', '-1'] }],
      wrap: false,
      offset: 0,
      remaining,
      needed
    };
  }

  if (needed <= remaining + 0.05) {
    return {
      inputs: [{
        file: closeup.file,
        options: ['-ss', offset.toFixed(3), '-t', (needed + pad).toFixed(3)]
      }],
      wrap: false,
      offset,
      remaining,
      needed
    };
  }

  return {
    inputs: [
      { file: closeup.file, options: ['-ss', offset.toFixed(3), '-t', (remaining + pad).toFixed(3)] },
      { file: closeup.file, options: ['-stream_loop', '-1'] }
    ],
    wrap: true,
    offset,
    remaining,
    needed
  };
}

function buildCloseupPrepFilters({ closeupIndex, wrap, target, duration, closeupFps, prefix = '', remaining = 0 }) {
  const fps = needsFpsConvert(target.fps, closeupFps) ? `fps=${target.fps},` : '';
  const tail = prefixed(prefix, 'cu_tail');
  const loop = prefixed(prefix, 'cu_loop');
  const src = prefixed(prefix, 'cu_src');
  const dur = Math.max(0.05, duration);
  if (wrap) {
    const tailDur = Math.max(0.05, Number(remaining) || 0).toFixed(3);
    const loopDur = Math.max(0.05, dur - Number(tailDur)).toFixed(3);
    return {
      filters: [
        `[${closeupIndex}:v:0]trim=duration=${tailDur},setpts=PTS-STARTPTS[${tail}]`,
        `[${closeupIndex + 1}:v:0]trim=duration=${loopDur},setpts=PTS-STARTPTS[${loop}]`,
        `[${tail}][${loop}]concat=n=2:v=1:a=0,` +
          `trim=duration=${dur.toFixed(3)},setpts=PTS-STARTPTS,${fps}setsar=1[${src}]`
      ],
      // Дальше coverFilter дописывает `,scale=...` — поэтому здесь уже должна
      // быть цепочка фильтров, а не голая метка `[cu_src],scale` (пустой фильтр).
      prep: `[${src}]setsar=1`
    };
  }

  return {
    filters: [],
    prep: `[${closeupIndex}:v:0]trim=duration=${dur.toFixed(3)},setpts=PTS-STARTPTS,${fps}setsar=1`
  };
}

/**
 * Делит кадр на две половины: слева смонтированный ролик, справа второе видео.
 *
 * Каждая половина заполняется независимо (cover), поэтому вертикальный 9:16
 * исходник сохраняет полный рост в колонке 540×1080, а не обрезается сверху
 * и снизу до квадрата. Правая половина по умолчанию увеличена в 1.8 раза.
 */
function buildSplitFilters({
  baseLabel,
  closeupIndex,
  closeupWrap,
  closeup,
  montage,
  outputLabel,
  target,
  split,
  duration,
  prefix = '',
  closeupRemaining = 0
}) {
  const width = target.width;
  const height = target.height;

  const leftWidth = clamp(evenRound((width * split.leftShare) / 100), 2, width - 2);
  const rightWidth = width - leftWidth;
  const featherLimit = Math.max(0, Math.min(leftWidth, rightWidth) - 2);
  const requested = clamp(split.feather, 0, featherLimit);
  const feather = requested > 0 ? Math.max(2, requested) : 0;

  const filters = [];
  const layout = { width, height, leftWidth, rightWidth, feather };
  const L = (name) => prefixed(prefix, name);

  const leftSrc = { width: montage.width, height: montage.height };
  const rightSrc = { width: closeup.width, height: closeup.height };
  const closeupPrep = buildCloseupPrepFilters({
    closeupIndex,
    wrap: Boolean(closeupWrap),
    target,
    duration,
    closeupFps: closeup.fps,
    prefix,
    remaining: closeupRemaining
  });
  filters.push(...closeupPrep.filters);
  const rightPrep = closeupPrep.prep;

  if (feather === 0) {
    filters.push(
      coverFilter(
        `[${baseLabel}]setsar=1,`,
        leftSrc, leftWidth, height, split.leftZoom, split.leftOffset, width,
        L('splitLeft')
      )
    );
    filters.push(
      coverFilter(
        `${rightPrep},`,
        rightSrc, rightWidth, height, split.rightZoom, split.rightOffset, width,
        L('splitRight')
      )
    );
    filters.push(`[${L('splitLeft')}][${L('splitRight')}]hstack=inputs=2:shortest=1[${outputLabel}]`);
    return { filters, layout };
  }

  const rightWindow = rightWidth + feather;
  const seam = leftWidth - feather;

  filters.push(
    coverFilter(
      `[${baseLabel}]setsar=1,`,
      leftSrc, leftWidth + feather, height, split.leftZoom, split.leftOffset, width,
      L('splitLeftWide')
    )
  );
  filters.push(`[${L('splitLeftWide')}]pad=${width}:${height}:0:0:black[${L('splitBase')}]`);
  filters.push(
    coverFilter(
      `${rightPrep},`,
      rightSrc, rightWindow, height, split.rightZoom, split.rightOffset, width,
      L('splitRightRgb')
    )
  );
  filters.push(`[${L('splitRightRgb')}]format=${alphaFormatFor(target.pixelFormat)}[${L('splitRight')}]`);
  filters.push(buildFeatherMaskFilter({
    width: rightWindow,
    height,
    fps: target.fps,
    duration,
    feather,
    outputLabel: L('splitMask')
  }));
  filters.push(`[${L('splitRight')}][${L('splitMask')}]alphamerge=shortest=1[${L('splitSoft')}]`);
  filters.push(
    `[${L('splitBase')}][${L('splitSoft')}]overlay=x=${seam}:y=0:shortest=1:format=yuv444:alpha=straight[${outputLabel}]`
  );

  return { filters, layout };
}

/**
 * Собирает список входов, граф фильтров и карту потоков для одного файла.
 *
 * Исходник подключается двумя отдельными входами (голова и хвост) вместо
 * split+trim: так ffmpeg не буферизует хвост видео в памяти, пока пишется
 * начало ролика.
 */
function buildGraph({
  source,
  shorts,
  overlay,
  closeup,
  closeupStart,
  split,
  target,
  splitAt,
  overlayOpacity,
  duration,
  labelPrefix = '',
  inputBase = 0,
  applyPace = false
}) {
  const inputs = [];
  const filters = [];
  const L = (name) => prefixed(labelPrefix, name);

  const headDuration = splitAt;
  const tailDuration = Math.max(0, source.duration - splitAt);

  // При сплите монтаж держит пропорции исходника и высоту холста: вертикальный
  // 9:16 не режется сверху и снизу до квадрата, а потом заполняет левую колонку.
  const montage = closeup
    ? {
        width: evenRound(target.height * (source.width / source.height)),
        height: target.height,
        fps: target.fps,
        fit: target.fit,
        pixelFormat: target.pixelFormat
      }
    : target;

  const headIndex = inputBase + inputs.length;
  inputs.push({ file: source.file, options: segmentInputOptions(0, headDuration) });
  const tailIndex = inputBase + inputs.length;
  inputs.push({ file: source.file, options: segmentInputOptions(splitAt, tailDuration) });
  const shortsIndex = inputBase + inputs.length;
  inputs.push({ file: shorts.file, options: segmentInputOptions(0, shorts.duration) });

  let overlayIndex = -1;
  if (overlay) {
    // Бесконечный луп: короткий оверлей повторяется, длинный обрежется по shortest=1.
    overlayIndex = inputBase + inputs.length;
    inputs.push({ file: overlay.file, options: ['-stream_loop', '-1'], pace: false });
  }

  let closeupIndex = -1;
  let closeupWrap = false;
  let closeupRemaining = 0;
  if (closeup) {
    // Правая половина идёт по таймлайну партии: ролик N продолжает с того места,
    // где закончился ролик N-1. Если файл кончился — начинается сначала.
    // Playhead и буфер входов считаются заново для этого Shorts — хвост
    // предыдущей операции сюда не подмешивается.
    const planned = planCloseupInputs(closeup, closeupStart, duration);
    closeupIndex = inputBase + inputs.length;
    closeupWrap = planned.wrap;
    closeupRemaining = planned.remaining;
    planned.inputs.forEach((input) => inputs.push({ ...input, pace: false }));
  }

  const segments = [
    { videoInput: headIndex, audioSource: source, audioInput: headIndex, duration: headDuration, fps: source.fps, width: source.width, height: source.height },
    { videoInput: shortsIndex, audioSource: shorts, audioInput: shortsIndex, duration: shorts.duration, fps: shorts.fps, width: shorts.width, height: shorts.height },
    { videoInput: tailIndex, audioSource: source, audioInput: tailIndex, duration: tailDuration, fps: source.fps, width: source.width, height: source.height }
  ];

  const concatLabels = [];
  segments.forEach((segment, i) => {
    const videoLabel = L(`v${i}`);
    const audioLabel = L(`a${i}`);

    filters.push(videoSegmentFilter(
      `${segment.videoInput}:v:0`,
      videoLabel,
      montage,
      segment.fps,
      { width: segment.width, height: segment.height },
      segment.duration
    ));

    // Сегмент без звука заменяется тишиной, иначе concat не соберёт дорожку.
    if (segment.audioSource.hasAudio) {
      filters.push(audioSegmentFilter(`${segment.audioInput}:a:0`, audioLabel, segment.duration));
    } else {
      filters.push(silentSegmentFilter(audioLabel, segment.duration));
    }

    concatLabels.push(`[${videoLabel}][${audioLabel}]`);
  });

  filters.push(`${concatLabels.join('')}concat=n=${segments.length}:v=1:a=1[${L('cv')}][${L('ca')}]`);

  let videoOut = L('cv');
  let layout = null;

  if (closeup) {
    const built = buildSplitFilters({
      baseLabel: videoOut,
      closeupIndex,
      closeupWrap,
      closeup,
      montage,
      outputLabel: L('sv'),
      target,
      split: normalizeSplit(split),
      duration,
      prefix: labelPrefix,
      closeupRemaining
    });
    filters.push(...built.filters);
    layout = built.layout;
    videoOut = L('sv');
  }

  // Оверлей ложится последним — поверх уже собранного split-screen.
  if (overlay) {
    const opacity = clamp(Number(overlayOpacity) / 100, 0, 1);
    const overlayFps = needsFpsConvert(target.fps, overlay.fps) ? `fps=${target.fps},` : '';
    const overlayAlpha = opacity >= 0.999
      ? 'format=rgba'
      : `format=rgba,colorchannelmixer=aa=${opacity.toFixed(3)}`;
    filters.push(
      `[${overlayIndex}:v:0]setpts=PTS-STARTPTS,${overlayFps}` +
        `scale=${target.width}:${target.height}:force_original_aspect_ratio=increase:flags=${SCALE_FLAGS},` +
        `crop=${target.width}:${target.height},setsar=1,${overlayAlpha}[${L('ovl')}]`
    );
    filters.push(`[${videoOut}][${L('ovl')}]overlay=x=0:y=0:shortest=1:eof_action=pass:format=auto[${L('vout')}]`);
    videoOut = L('vout');
  }

  // Наложения работают в форматах с альфой и могут отдать 4:4:4, который не
  // возьмёт профиль кодека, — поэтому кадр всегда приводится к целевому формату.
  filters.push(`[${videoOut}]format=${target.pixelFormat}[${L('vfinal')}]`);

  const audioOut = L('ca');
  const pace = Boolean(applyPace && target.pixelFormat === 'yuv420p');
  return { inputs, filters, videoOut: L('vfinal'), audioOut, layout, pace };
}

// ---------------------------------------------------------------------------
// Обработка одного файла
// ---------------------------------------------------------------------------

function resolveTarget(frameKey, fitKey, source, plan) {
  const frame = FRAME_PRESETS[frameKey] || FRAME_PRESETS[DEFAULTS.frame];
  return {
    width: evenRound(frame.width || source.width),
    height: evenRound(frame.height || source.height),
    fps: chooseOutputFps(source.fps),
    fit: FIT_MODES[fitKey] ? fitKey : DEFAULTS.fit,
    pixelFormat: plan.pixelFormat
  };
}

function resolveSplitAt(source, percent) {
  const minSegment = Math.max(0.05, 2 / source.fps);
  return clamp(
    (source.duration * percent) / 100,
    minSegment,
    Math.max(minSegment, source.duration - minSegment)
  );
}

/**
 * ffmpeg-static на Windows — 6.1.1. Опция `-/filter_complex` появилась только в 7.0
 * и на 6.1 даёт «Error splitting the argument list: Option not found» на каждом файле.
 * Короткий граф — обычный -filter_complex. Длинный — -filter_complex_script (есть с 1.x).
 */
function attachFilterGraph(command, filters) {
  const text = Array.isArray(filters) ? filters.filter(Boolean).join(';') : String(filters || '');
  if (text.length < FILTER_SCRIPT_THRESHOLD) {
    command.complexFilter(text);
    return null;
  }
  const script = path.join(
    os.tmpdir(),
    `shorts-fc-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}.ffilter`
  );
  fs.writeFileSync(script, text, 'utf8');
  command._complexFilters('-filter_complex_script', script);
  command._filterScriptPath = script;
  return script;
}

function applyInputs(command, inputs, plan, pace) {
  inputs.forEach((input) => {
    const added = command.input(input.file);
    if (plan.hwaccel) added.inputOptions(['-hwaccel', plan.hwaccel]);
    if (plan.resourceUsage === 'low') added.inputOptions(['-threads', '1']);
    if (pace && input.pace !== false) added.inputOptions(paceGlobalArgs(plan));
    if (input.options && input.options.length) added.inputOptions(input.options);
  });
}

function formatEta(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '—';
  const total = Math.max(0, Math.round(seconds));
  const mm = String(Math.floor(total / 60)).padStart(2, '0');
  const ss = String(total % 60).padStart(2, '0');
  return `${mm}:${ss}`;
}

function runCommand(command, { plan, totalDuration, onProgress, onCommand, onDebug }) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let lastEmit = 0;
    const cleanup = () => safeUnlink(command._filterScriptPath);
    const finish = (handler) => (value) => {
      if (settled) return;
      settled = true;
      Promise.resolve(waitForFfmpegExit(command))
        .catch(() => {})
        .then(() => {
          cleanup();
          handler(value);
        });
    };

    command.on('start', (commandLine) => {
      command._startedAt = Date.now();
      lowerFfmpegPriority(command);
      if (typeof onCommand === 'function') onCommand(command);
      if (typeof onDebug === 'function') onDebug(commandLine);
    });
    command.on('stderr', (line) => {
      if (typeof onDebug === 'function') onDebug(line);
    });
    command.on('progress', (progress) => {
      if (typeof onProgress !== 'function' || totalDuration <= 0) return;
      const now = Date.now();
      if (now - lastEmit < PROGRESS_INTERVAL_MS) return;
      lastEmit = now;
      const done = timemarkToSeconds(progress.timemark);
      const percent = clamp((done / totalDuration) * 100, 0, 99.9);
      const fps = Number(progress.currentFps) || 0;
      const elapsedSec = (now - (command._startedAt || now)) / 1000;
      const eta = percent > 1.5 && elapsedSec > 0.4
        ? ((100 - percent) / percent) * elapsedSec
        : 0;
      onProgress(percent, {
        fps,
        kbps: Number(progress.currentKbps) || 0,
        eta,
        timemark: progress.timemark
      });
    });
    command.on('error', finish((err) => {
      if (isCommandTooLong(err) || isUnknownFfmpegOption(err)) {
        reject(err);
        return;
      }
      if (plan && plan.usingGpu) {
        reject(new GpuUnavailableError(err));
        return;
      }
      reject(err);
    }));
    command.on('end', finish(() => resolve()));
    try {
      command.run();
    } catch (err) {
      finish((value) => reject(value))(err);
    }
  });
}

/**
 * @param {object} params
 * @param {object} params.source      результат probeMedia() для исходника
 * @param {object} params.shorts      результат probeMedia() для Shorts
 * @param {object|null} params.overlay результат probeMedia() для оверлея
 * @param {object|null} params.closeup результат probeMedia() для правой половины
 * @param {number} [params.closeupStart] секунда внутри второго видео, с которой начинается правая половина
 * @param {object} params.split       настройки раскладки split-screen
 * @param {string} params.outputFile  путь к esN.mov
 * @param {number} params.percent     процент обрезки (50..99)
 * @param {string} params.encoder     ключ ENCODERS
 * @param {object} [params.plan]      результат resolveEncodePlan()
 * @param {string} params.frame       ключ FRAME_PRESETS (размер итогового кадра)
 * @param {string} params.fit         ключ FIT_MODES (обрезать или вписать)
 * @param {number} params.overlayOpacity 0..100
 * @param {function} params.onProgress вызывается с (0..100)
 * @param {function} params.onCommand  получает объект команды (для остановки)
 * @param {function} params.onDebug    строка запуска ffmpeg / stderr
 */
function renderVideo(params) {
  const {
    source,
    shorts,
    overlay,
    closeup,
    split,
    outputFile,
    percent,
    encoder,
    overlayOpacity,
    onProgress,
    onCommand,
    onDebug
  } = params;

  const hardware = params.hardware || detectHardware();
  const seedPlan = params.plan || { pixelFormat: 'yuv420p' };
  const target = resolveTarget(params.frame, params.fit, source, seedPlan);
  const plan = params.plan && params.plan.videoOptions
    ? params.plan
    : resolveEncodePlan(encoder, {
      accel: params.accel,
      exportMode: params.exportMode,
      resourceUsage: params.resourceUsage,
      forceCpu: params.forceCpu,
      target
    }, hardware);
  const timeline = isolateJobTimeline({
    closeupStart: params.closeupStart,
    splitAt: Number.isFinite(Number(params.splitAt)) && Number(params.splitAt) > 0
      ? Number(params.splitAt)
      : resolveSplitAt(source, percent),
    duration: Number.isFinite(Number(params.duration)) && Number(params.duration) > 0
      ? Number(params.duration)
      : source.duration + shorts.duration,
    percent
  });
  const splitAt = timeline.splitAt;
  const totalDuration = timeline.duration;

  const { inputs, filters, videoOut, audioOut, layout, pace } = buildGraph({
    source,
    shorts,
    overlay,
    closeup,
    closeupStart: timeline.closeupStart,
    split,
    target,
    splitAt,
    overlayOpacity,
    duration: totalDuration,
    applyPace: Boolean(plan.pace)
  });

  const command = ffmpeg();
  applyInputs(command, inputs, plan, pace);
  command._global([
    '-filter_complex_threads', String(plan.threads.filterThreads),
    '-filter_threads', String(plan.threads.filterThreads)
  ]);
  attachFilterGraph(command, filters);
  command
    .outputOptions([
      '-map', `[${videoOut}]`,
      '-map', `[${audioOut}]`,
      ...plan.videoOptions,
      ...plan.audioOptions,
      '-ar', String(AUDIO_SAMPLE_RATE),
      '-ac', '2',
      '-r', String(target.fps),
      '-pix_fmt', plan.pixelFormat,
      '-vsync', 'cfr',
      ...(plan.extraOptions || []),
      '-y'
    ])
    .format(outputContainer(plan.encoderKey || encoder))
    .output(outputFile);

  return runCommand(command, {
    plan,
    totalDuration,
    onProgress: typeof onProgress === 'function'
      ? (pct, meta) => onProgress(pct, meta)
      : null,
    onCommand,
    onDebug
  }).then(() => {
    if (typeof onProgress === 'function') onProgress(100, { fps: 0, eta: 0 });
    return {
      outputFile,
      splitAt,
      layout,
      expectedDuration: totalDuration
    };
  });
}


async function verifyOutputFile(file, expected = {}) {
  if (!file || !fs.existsSync(file)) throw new Error('итоговый файл не появился');
  const size = fs.statSync(file).size;
  if (size < MIN_OUTPUT_BYTES) throw new Error('итоговый файл слишком маленький');
  const info = await probeMedia(file);
  if (expected.requireAudio && !info.hasAudio) throw new Error('в результате нет звука');
  if (expected.width && expected.height) {
    if (Math.abs(info.width - expected.width) > 2 || Math.abs(info.height - expected.height) > 2) {
      throw new Error(`ожидали ${expected.width}x${expected.height}, получили ${info.width}x${info.height}`);
    }
  }
  if (Number.isFinite(expected.duration) && Math.abs(info.duration - expected.duration) > 0.55) {
    throw new Error(`длительность ${info.duration.toFixed(2)}с вместо ${expected.duration.toFixed(2)}с`);
  }
  return { info, size };
}

/** Минимальный размер готового результата: всё меньше считаем незавершённым. */
const MIN_RENDER_BYTES = 64 * 1024;

/**
 * Очистка очереди рендера: удаляем незавершённые результаты (esN.mp4 / esN.mov
 * нулевого размера, .part и .tmp) и временные filter-script-файлы ffmpeg.
 * Готовые файлы не трогаем.
 */
function clearRenderArtifacts(options = {}) {
  const prefix = options.outputPrefix || DEFAULTS.outputPrefix;
  const outputDir = options.outputDir;
  const removed = [];
  if (outputDir && fs.existsSync(outputDir)) {
    const pattern = new RegExp(`^${escapeRegExp(prefix)}\\d+\\.(mov|mp4)(\\.part|\\.tmp)?$`, 'i');
    fs.readdirSync(outputDir).forEach((name) => {
      if (!pattern.test(name)) return;
      const file = path.join(outputDir, name);
      let size = 0;
      try {
        size = fs.statSync(file).size;
      } catch {
        return;
      }
      const partial = /\.(part|tmp)$/i.test(name) || size < MIN_RENDER_BYTES;
      if (!partial) return;
      safeUnlink(file);
      if (!fs.existsSync(file)) removed.push(name);
    });
  }
  try {
    const temp = os.tmpdir();
    fs.readdirSync(temp).forEach((name) => {
      if (!/^shorts-fc-.*\.ffilter$/i.test(name)) return;
      const file = path.join(temp, name);
      safeUnlink(file);
      if (!fs.existsSync(file)) removed.push(name);
    });
  } catch {
    /* нет доступа к temp — не критично */
  }
  return { removed: removed.length, files: removed };
}

// ---------------------------------------------------------------------------
// Пакетная обработка
// ---------------------------------------------------------------------------

/**
 * Управляет очередью файлов: ошибка на одном ролике не останавливает остальные.
 *
 * hooks: { onLog(level, message), onProgress(state), onFileDone(info) }
 */
class BatchProcessor {
  constructor(settings, hooks = {}) {
    this.settings = settings;
    this.hooks = hooks;
    this.cancelled = false;
    this.currentCommand = null;
    this.currentOutput = null;
    this.running = false;
  }

  log(level, message) {
    if (typeof this.hooks.onLog === 'function') this.hooks.onLog(level, message);
  }

  emitProgress(state) {
    if (typeof this.hooks.onProgress === 'function') this.hooks.onProgress(state);
  }

  stop() {
    if (!this.running || this.cancelled) return;
    this.cancelled = true;
    this.log('warn', 'Получен запрос на остановку. Завершаем текущий файл…');
    if (this.currentCommand) {
      try {
        this.currentCommand.kill('SIGKILL');
      } catch (err) {
        this.log('error', `Не удалось остановить FFmpeg: ${err.message}`);
      }
    }
  }

  validate() {
    const s = this.settings;
    const errors = [];

    if (!s.sourceDir || !fs.existsSync(s.sourceDir)) errors.push('Папка с исходными видео не найдена.');
    if (!s.shortsFile || !fs.existsSync(s.shortsFile)) errors.push('Файл Shorts не найден.');
    if (s.useOverlay && (!s.overlayFile || !fs.existsSync(s.overlayFile))) {
      errors.push('Оверлей включён, но файл не выбран или не найден.');
    }
    if (s.useSplit && (!s.closeupFile || !fs.existsSync(s.closeupFile))) {
      errors.push('Split-screen включён, но видео для правой половины не выбрано или не найдено.');
    }
    if (!s.outputDir) errors.push('Не выбрана папка для сохранения результата.');

    const percent = Number(s.percent);
    if (!Number.isFinite(percent) || percent < 50 || percent > 99) {
      errors.push('Процент обрезки должен быть числом от 50 до 99.');
    }

    return errors;
  }

  async run() {
    if (this.running) throw new Error('Обработка уже запущена');
    this.running = true;

    const startedAt = Date.now();
    const summary = { total: 0, done: 0, failed: 0, cancelled: false, results: [], elapsedMs: 0 };

    try {
      const errors = this.validate();
      if (errors.length) {
        errors.forEach((message) => this.log('error', message));
        throw new Error(errors[0]);
      }

      const s = this.settings;
      const percent = clamp(Number(s.percent), 50, 99);
      const hardware = detectHardware();
      const exportOptions = {
        exportMode: normalizeExportMode(s.exportMode),
        resourceUsage: normalizeResourceUsage(s.resourceUsage || s.accel),
        forceCpu: s.accel === 'cpu' || s.forceCpu === true
      };
      const encoder = resolveEncoderKey(s.encoder, hardware);
      const prefix = s.outputPrefix || DEFAULTS.outputPrefix;
      const overlayOpacity = Number.isFinite(Number(s.overlayOpacity)) ? Number(s.overlayOpacity) : 100;
      const plan = resolveEncodePlan(encoder, exportOptions, hardware);

      fs.mkdirSync(s.outputDir, { recursive: true });

      const sameDir = path.resolve(s.outputDir) === path.resolve(s.sourceDir);
      const sources = listVideoFiles(s.sourceDir, { skipOutputNames: sameDir, outputPrefix: prefix });
      summary.total = sources.length;

      if (!sources.length) {
        throw new Error('В выбранной папке нет видеофайлов.');
      }

      const frame = FRAME_PRESETS[s.frame] ? s.frame : DEFAULTS.frame;
      const fit = FIT_MODES[s.fit] ? s.fit : DEFAULTS.fit;

      this.log('info', `Найдено видео: ${sources.length}`);
      this.log('info', `FFmpeg: ${ffmpegPath}`);
      this.log(
        'info',
        `Экспорт: ${plan.label}; обрезка ${percent}%; один процесс (MAX_EXPORT_JOBS=${MAX_EXPORT_JOBS})`
      );
      if (plan.encoderKey === 'prores') {
        this.log('info', `ProRes на CPU, ${plan.threads.encodeThreads} из ${plan.threads.cores} потоков`);
      } else if (plan.usingGpu) {
        this.log(
          'info',
          `Кодирование на GPU (${plan.encoderName}), CPU только склейка (${plan.threads.filterThreads} поток(а) фильтров)`
        );
      } else {
        this.log(
          'info',
          `Software ${plan.encoderName}, ${plan.threads.encodeThreads} из ${plan.threads.cores} потоков, пресет не slower/veryslow`
        );
      }
      if (plan.encoderKey !== 'prores') {
        if (plan.pace) {
          const speed = encodePaceSpeed(plan);
          this.log(
            'info',
            plan.usingGpu
              ? `GPU: чтение ${speed}× без стартового выброса; следующий файл — после закрытия NVENC`
              : `Режим LOW: чтение входа ограничено ${speed}×, чтобы нагрузка не скакала`
          );
        } else {
          this.log(
            'info',
            `Без искусственного потолка fps. Файл сразу в ${prefix}N${outputExtension(encoder)}`
          );
        }
      }
      if (hardware.compiledGpu && hardware.compiledGpu.length) {
        this.log('info', `Hardware Encoder: ${plan.vendor || 'нет'} · в FFmpeg: ${hardware.compiledGpu.join(', ')}`);
      }
      if (!plan.usingGpu && !exportOptions.forceCpu && hardware.probeError) {
        this.log('warn', `Тест видеокарты: ${hardware.probeError}`);
      }
      this.log(
        'info',
        `Кадр: ${FRAME_PRESETS[frame].label}, ${FIT_MODES[fit].label.toLowerCase()}`
      );

      const shorts = await probeMedia(s.shortsFile);
      this.log(
        'info',
        `Shorts: ${path.basename(shorts.file)} — ${shorts.width}x${shorts.height}, ` +
          `${formatDuration(shorts.duration)}${shorts.hasAudio ? '' : ', без звука'}`
      );

      let overlay = null;
      if (s.useOverlay) {
        overlay = await probeMedia(s.overlayFile);
        this.log(
          'info',
          `Оверлей: ${path.basename(overlay.file)} — ${overlay.width}x${overlay.height}, ` +
            `${formatDuration(overlay.duration)}, прозрачность ${100 - overlayOpacity}%`
        );
      }

      const split = normalizeSplit(s.split);
      let closeup = null;
      if (s.useSplit) {
        closeup = await probeMedia(s.closeupFile);
        this.log(
          'info',
          `Split-screen: ${path.basename(closeup.file)} — ${closeup.width}x${closeup.height}, ` +
            `${formatDuration(closeup.duration)} (звук второго видео не используется)`
        );
        this.log(
          'info',
          `Раскладка: левая часть ${split.leftShare}% (зум ${split.leftZoom.toFixed(2)}, ` +
            `сдвиг ${split.leftOffset}%), правая — зум ${split.rightZoom.toFixed(2)}, ` +
            `сдвиг ${split.rightOffset}%, граница ${split.feather ? `мягкая ${split.feather} px` : 'чёткая'}`
        );
        this.log(
          'info',
          'Крупный план справа идёт подряд: каждый следующий ролик продолжает с того места, где закончился предыдущий'
        );
      }

      let closeupHead = 0;
      const jobs = [];

      for (let i = 0; i < sources.length; i += 1) {
        if (this.cancelled) break;

        const sourceFile = sources[i];
        const fileName = path.basename(sourceFile);
        const outputFile = path.join(s.outputDir, `${prefix}${i + 1}${outputExtension(encoder)}`);
        const humanIndex = `${i + 1}/${sources.length}`;

        try {
          const source = await probeMedia(sourceFile);
          if (source.duration <= 0.2) {
            throw new Error('Слишком короткое или повреждённое видео.');
          }

          this.log(
            'info',
            `[${humanIndex}] ${fileName} — ${source.width}x${source.height}, ${source.fps} fps, ` +
              `${formatDuration(source.duration)}${source.hasAudio ? '' : ', без звука'}`
          );
          this.log(
            'info',
            `[${humanIndex}] Точка вставки: ${formatDuration((source.duration * percent) / 100)} ` +
              `(${percent}%) → ${path.basename(outputFile)}`
          );

          const target = resolveTarget(frame, fit, source, plan);
          const jobPlan = resolveEncodePlan(encoder, { ...exportOptions, target }, hardware);
          if (i === 0) {
            const work = describeEncodeWork({ overlay, closeup, source, shorts, target });
            this.log(
              'info',
              `Smart render: ${work.reason}. Масштаб: ${work.scale ? 'да' : 'нет'}, ` +
                `FPS: ${work.keepSourceFps ? `как у исходника ${target.fps}` : `приводим к ${target.fps}`}, ` +
                `оверлей: ${work.overlay ? 'да' : 'нет'}, split: ${work.split ? 'да' : 'нет'}`
            );
          }
          const estimated = estimateOutputBytes({
            width: target.width,
            height: target.height,
            fps: target.fps,
            duration: source.duration + shorts.duration,
            encoderKey: encoder,
            exportMode: exportOptions.exportMode
          });
          this.log(
            'info',
            `[${humanIndex}] ${target.width}x${target.height} ${target.fps} fps · ${jobPlan.encoderName}` +
              `${jobPlan.cq != null ? ` CQ/CRF ${jobPlan.cq}` : ''} · оценка ~${(estimated / 1024 / 1024).toFixed(1)} МБ`
          );
          const splitAt = resolveSplitAt(source, percent);
          const duration = source.duration + shorts.duration;
          const timeline = isolateJobTimeline({
            closeupStart: closeup ? wrapCloseupOffset(closeupHead, closeup.duration) : 0,
            splitAt,
            duration,
            percent
          });
          if (closeup) {
            this.log(
              'info',
              `[${humanIndex}] Крупный план справа: с ${formatDuration(timeline.closeupStart)} ` +
                `(таймлайн второго видео)`
            );
          }

          jobs.push({
            index: i,
            source,
            outputFile,
            fileName,
            humanIndex,
            closeupStart: timeline.closeupStart,
            target,
            splitAt: timeline.splitAt,
            duration: timeline.duration,
            percent: timeline.percent,
            encoder,
            hardware,
            frame,
            fit,
            plan: jobPlan,
            estimatedBytes: estimated
          });
          // Playhead двигаем по плану этого ролика, не по фактическому хвосту.
          // Иначе 20% текущего файла оседают как «остаток» следующего Shorts.
          if (closeup) closeupHead += timeline.duration;
        } catch (err) {
          if (this.cancelled) break;
          summary.failed += 1;
          this.log('error', `[${humanIndex}] Ошибка на файле ${fileName}: ${shortenFfmpegError(err.message)}`);
          safeUnlink(outputFile);
          this.emitProgress({
            fileIndex: i,
            total: sources.length,
            fileName,
            filePercent: 0,
            overallPercent: ((i + 1) / sources.length) * 100,
            status: `Ошибка ${humanIndex}: ${fileName}`,
            done: summary.done,
            failed: summary.failed
          });
        }
      }

      const bindCommand = (command) => {
        this.currentCommand = command;
        if (this.cancelled) {
          try {
            command.kill('SIGKILL');
          } catch (err) {
            /* процесс мог ещё не стартовать */
          }
        }
      };

      const emitJobProgress = (job, filePercent, status, extra = {}) => {
        const encodePlan = extra.plan || job.plan || plan;
        this.emitProgress({
          fileIndex: job.index,
          total: sources.length,
          fileName: job.fileName,
          outputName: path.basename(job.outputFile),
          filePercent,
          overallPercent: ((job.index + filePercent / 100) / sources.length) * 100,
          status: status || `Rendering ${job.humanIndex}: ${job.fileName} — ${Math.round(filePercent)}%`,
          done: summary.done,
          failed: summary.failed,
          fps: extra.fps || 0,
          eta: extra.eta != null ? formatEta(extra.eta) : '—',
          encoderName: encodePlan.encoderName || encodePlan.label,
          vendor: encodePlan.vendor || (encodePlan.usingGpu ? 'GPU' : 'CPU'),
          resolution: job.target ? `${job.target.width}x${job.target.height}` : '',
          estimatedSize: job.estimatedBytes
            ? `${Math.max(1, Math.round(job.estimatedBytes / 1024 / 1024))} MB`
            : '',
          usingGpu: Boolean(encodePlan.usingGpu)
        });
      };

      const finished = new Set();
      const markJobDone = async (job) => {
        if (!job || finished.has(job.outputFile)) return false;
        const verified = await verifyOutputFile(job.outputFile, {
          requireAudio: true,
          width: job.target && job.target.width,
          height: job.target && job.target.height,
          duration: job.duration
        });
        finished.add(job.outputFile);
        summary.done += 1;
        summary.results.push({ source: job.source.file, output: job.outputFile, size: verified.size });
        this.log(
          'success',
          `[${job.humanIndex}] Готово: ${path.basename(job.outputFile)} ` +
            `(${(verified.size / 1024 / 1024).toFixed(1)} МБ, ${verified.info.width}x${verified.info.height}, ` +
            `${verified.info.fps} fps)`
        );
        emitJobProgress(job, 100, `Завершено ${job.index + 1} из ${sources.length}`);
        return true;
      };

      const encodeOne = async (job, encodePlan) => {
        this.currentOutput = job.outputFile;
        emitJobProgress(job, 0, `Обработка ${job.humanIndex}: ${job.fileName}`);
        await renderVideo({
          source: job.source,
          shorts,
          overlay,
          closeup,
          closeupStart: job.closeupStart,
          splitAt: job.splitAt,
          duration: job.duration,
          split,
          outputFile: job.outputFile,
          percent: job.percent,
          encoder,
          plan: encodePlan,
          hardware,
          frame,
          fit,
          overlayOpacity,
          onCommand: bindCommand,
          onDebug: (line) => {
            if (this.settings.verbose) this.log('debug', line);
          },
          onProgress: (filePercent, meta = {}) => emitJobProgress(job, filePercent, null, {
            plan: encodePlan,
            fps: meta.fps,
            eta: meta.eta
          })
        });
      };

      let encodePlan = plan;
      let encodedAny = false;
      let previousPlan = null;

      for (const job of jobs) {
        if (this.cancelled) break;
        if (encodedAny) await sleep(handoffDelayMs(previousPlan || encodePlan));
        if (this.cancelled) break;
        encodedAny = true;
        let activePlan = job.plan || encodePlan;

        try {
          try {
            await encodeOne(job, activePlan);
          } catch (err) {
            if (this.cancelled) throw err;
            if (err && err.gpuFallback && activePlan.usingGpu) {
              this.log(
                'warn',
                `Видеокарта не приняла кадр (${shortenFfmpegError(err.message)}), дальше кодируем на процессоре`
              );
              safeUnlink(job.outputFile);
              await sleep(handoffDelayMs(activePlan));
              encodePlan = resolveEncodePlan(encoder, { ...exportOptions, forceCpu: true, target: job.target }, hardware);
              activePlan = encodePlan;
              await encodeOne(job, activePlan);
            } else {
              throw err;
            }
          }
          if (this.cancelled) {
            safeUnlink(job.outputFile);
            break;
          }
          if (!(await markJobDone(job))) {
            throw new Error(`Файл не записался: ${path.basename(job.outputFile)}`);
          }
        } catch (err) {
          if (this.cancelled) {
            safeUnlink(job.outputFile);
            break;
          }
          summary.failed += 1;
          this.log(
            'error',
            `[${job.humanIndex}] Ошибка на файле ${job.fileName}: ${shortenFfmpegError(err.message)}`
          );
          safeUnlink(job.outputFile);
          emitJobProgress(job, 0, `Ошибка ${job.humanIndex}: ${job.fileName}`);
        } finally {
          previousPlan = activePlan;
          this.currentCommand = null;
          this.currentOutput = null;
        }
      }

      summary.cancelled = this.cancelled;
      summary.elapsedMs = Date.now() - startedAt;
      return summary;
    } finally {
      this.running = false;
      this.currentCommand = null;
    }
  }
}

module.exports = {
  BatchProcessor,
  clearRenderArtifacts,
  MIN_RENDER_BYTES,
  ENCODERS,
  EXPORT_MODES,
  RESOURCE_MODES,
  ACCEL_MODES,
  FRAME_PRESETS,
  FIT_MODES,
  DEFAULTS,
  SPLIT_DEFAULTS,
  normalizeSplit,
  VIDEO_EXTENSIONS,
  ProcessingCancelledError,
  GpuUnavailableError,
  ffmpegPath,
  ffprobePath,
  detectHardware,
  resolveEncodePlan,
  resolveEncoderKey,
  perceptualCq,
  estimateOutputBytes,
  describeEncodeWork,
  chooseOutputFps,
  listVideoFiles,
  probeMedia,
  probeMediaViaFfmpeg,
  parseFfmpegProbe,
  ffprobeAvailable,
  renderVideo,
  formatDuration,
  outputContainer,
  outputExtension,
  wrapCloseupOffset,
  planCloseupInputs,
  isolateJobTimeline,
  segmentInputOptions,
  resolveSplitAt,
  buildFeatherMaskFilter,
  isVideoFile,
  shortenFfmpegError,
  ENCODE_PACE_SPEED,
  GPU_PACE_BALANCED,
  GPU_PACE_HIGH,
  MAX_EXPORT_JOBS,
  INTER_FILE_DELAY_MS,
  CPU_HANDOFF_MS,
  GPU_HANDOFF_MS,
  FILTER_SCRIPT_THRESHOLD,
  paceGlobalArgs,
  encodePaceSpeed,
  handoffDelayMs,
  attachFilterGraph,
  isUnknownFfmpegOption,
  fitStep,
  videoSegmentFilter
};
